#!/bin/bash


login_user=$(whoami)


encrypt_password()
{
    if [[ ${login_user} == "fsgbu_ormb" ]]; then
      echo -ne "enter db password:"
      read -sr Pd1
      echo
      echo -ne "Verifying entered db password:"
      read -sr Pd2
      echo  
      if [[ ${Pd1} == ${Pd2} ]]; then
        #echo ${Pd1} | base64 > dbp.enc
        echo ${Pd1} |  openssl enc -k openssltt -aes-256-cbc  -out dbp.enc
        echo  "Thank you ..encrypted successfull "
              
      else
        echo "enter db password and verifying db password is not match"
      fi
   else
    echo "script can't be executed,please execute script by appication user"
   fi

}

encrypt_password
 
